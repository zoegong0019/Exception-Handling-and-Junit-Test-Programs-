package fall22lab4;
/*
 * File name: [YourPurchaseTest.java ]
 
� Author: [ Zoe Gong, ID#040752463]
� Course: CST8284 � Section 311
� Assignment: Lab4
� Date: October,13,2022
� Professor: Justin Martin
� Purpose: 
 * use a unit testing framework JUnit to execute and evaluate test suites, as well
 * as make it easy to add test cases.

 * This lab has been completed for demo by: Zoe Gong
 */
import org.junit.Test;

import static org.junit.Assert.assertTrue;

import org.junit.Assert;

public class YourPurchasesTest
{
   private static final double EPSILON = 1E-12;

   @Test public void twoPurchases()
   {
      YourPurchases register = new YourPurchases();
      register.recordPurchase(0.75);
      register.recordPurchase(1.50);
      register.receivePayment(2, 0, 5, 0, 0);
      double expected = 0.25;
      Assert.assertEquals(expected, register.giveChange(), EPSILON);
    }
   
// YOUR TASKS ARE STATED HERE: 
   // RUN THE CODE YOU RECEIVED AND DEMO THAT THERE IS NO ERROR in YourPurchasesTest.java 

  
     
   }

