package fall22lab4;
/*
 * File name: [YourPurchaseTest2.java ]
 
� Author: [ Zoe Gong, ID#040752463]
� Course: CST8284 � Section 311
� Assignment: Lab4
� Date: October,13,2022
� Professor: Justin Martin
� Purpose: 
 * use a unit testing framework JUnit to execute and evaluate test suites, as well
 * as make it easy to add test cases.

 * This lab has been completed for demo by: Zoe Gong
 */
import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
public class YourPurchasesTest2 {

	private static final double EPSILON = 1E-12;
	
	//THIS TEST WOULD FAIL. 
	// TODO: WRITE ONE OR MORE TESTS TO SYSTEMATICALLY FIND THE SOURCE OF THE TEST FAILURE 
	
	@Test
	public void testCalculateChange() {
		YourPurchases aPurchase = new YourPurchases();
		aPurchase.recordPurchase(1.5);
		aPurchase.receivePayment(5, 0, 0, 0, 0);
		double changeResult = aPurchase.CalculateChange();
		double expected = 6.50;
	    Assert.assertEquals(expected, changeResult, EPSILON);
		assertTrue(true);
	}
	
	 // YOUR TASKS ARE STATED HERE: 
	   // RUN THE TEST CASE IN YourPurchasesTest2.java, TO SHOW AN EXAMPLE OF AN UNSUCCESSFUL EXECUTION
	   // IMPROVE THIS CODE BY SYSTEMATICALLY ADDING MORE TEST CASES (NOT ALREADY STATED IN THIS CODE)
	   // TO LOCATE THE METHOD THAT IS CAUSING THE TEST FAILURE
	   
	   // ADD NEW TEST CASES HERE!!!
	
	//Test recordPurchase() run properly
	@Test
	public void recordPurchase()	{
		YourPurchases aPurchase = new YourPurchases();
		aPurchase.recordPurchase(2.75);
		aPurchase.recordPurchase(3.50);
		aPurchase.receivePayment(4, 8, 0, 0, 0);
		double expected = 6.25;
		   Assert.assertEquals (expected,aPurchase.getPurchase(),EPSILON);
		   assertTrue(true);
	}

	//Test receivePayment() run properly
	public void testReceivePayment()		{
		YourPurchases aPurchase = new YourPurchases();
		aPurchase.recordPurchase(0.75);
		aPurchase.receivePayment(3, 2, 0, 0, 0);
		double expected =3.50 ;
		   Assert.assertEquals (expected, aPurchase.getPayment(),EPSILON);
		   assertTrue(true);
	}
	//Test if the actual change is the same as expected
	@Test
	public void testCalculateChange2() {
		YourPurchases aPurchase = new YourPurchases();
		aPurchase.recordPurchase(10.5);
		aPurchase.recordPurchase(1.3);
		aPurchase.receivePayment(5, 0, 0, 0, 0);
		double changeResult = aPurchase.CalculateChange();
		double expected = 16.80;
	    Assert.assertEquals(expected,changeResult, EPSILON);
		assertTrue(true);
	}
}
